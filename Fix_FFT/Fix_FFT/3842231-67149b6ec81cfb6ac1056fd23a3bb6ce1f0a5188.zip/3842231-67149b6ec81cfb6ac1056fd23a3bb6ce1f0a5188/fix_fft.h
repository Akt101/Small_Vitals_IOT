#ifndef FIX_FFT_H
#define FIX_FFT_H

int fix_fftr(short*, int, int);

#endif